INSERT INTO Customers (Name, Email, Phone)
VALUES 
('John Doe', 'john@example.com', '9999999999'),
('Jane Smith', 'jane@example.com', '8888888888');

INSERT INTO Accounts (CustomerID, AccountType, Balance)
VALUES 
(1, 'Savings', 5000.00),
(2, 'Current', 10000.00);
